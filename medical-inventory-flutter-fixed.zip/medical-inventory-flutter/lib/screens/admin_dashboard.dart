import 'package:flutter/material.dart';
import '../models/user.dart';
import '../models/medicine.dart';
import '../models/order.dart';
import '../services/api_service.dart';

class AdminDashboard extends StatefulWidget {
  final User user;
  final Function() onLogout;

  const AdminDashboard({
    Key? key,
    required this.user,
    required this.onLogout,
  }) : super(key: key);

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  late Future<List<Medicine>> _medicinesFuture;
  late Future<List<Order>> _ordersFuture;
  late Future<Map<String, dynamic>> _statsFuture;
  String? _message;

  final _nameController = TextEditingController();
  final _companyController = TextEditingController();
  final _stockController = TextEditingController();
  final _priceController = TextEditingController();
  final _expiryController = TextEditingController();
  final _commissionController = TextEditingController();
  final _schemeController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() {
    _medicinesFuture = ApiService.getMedicines().then(
      (data) => (data as List).map((m) => Medicine.fromJson(m)).toList(),
    );
    _ordersFuture = ApiService.getOrders().then(
      (data) => (data as List).map((o) => Order.fromJson(o)).toList(),
    );
    _statsFuture = ApiService.getStats();
  }

  void _addMedicine() async {
    try {
      await ApiService.addMedicine({
        'name': _nameController.text,
        'company': _companyController.text,
        'stock': int.parse(_stockController.text),
        'price': double.parse(_priceController.text),
        'expiry_date': _expiryController.text,
        'commission_pct': double.parse(_commissionController.text),
        'scheme': _schemeController.text,
      });
      _showMessage('✅ Medicine added!', Colors.green);
      _clearForm();
      _loadData();
    } catch (e) {
      _showMessage(e.toString().replaceAll('Exception: ', ''), Colors.red);
    }
  }

  void _updateOrderStatus(int orderId, String status) async {
    try {
      await ApiService.updateOrderStatus(orderId, status);
      _showMessage('✅ Order $status', Colors.green);
      _loadData();
    } catch (e) {
      _showMessage(e.toString().replaceAll('Exception: ', ''), Colors.red);
    }
  }

  void _clearForm() {
    _nameController.clear();
    _companyController.clear();
    _stockController.clear();
    _priceController.clear();
    _expiryController.clear();
    _commissionController.clear();
    _schemeController.clear();
  }

  void _showMessage(String msg, Color color) {
    setState(() => _message = msg);
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) setState(() => _message = null);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF2C3E50),
        title: const Text('Admin Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: widget.onLogout,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_message != null)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _message!.startsWith('✅') ? Colors.green.shade100 : Colors.red.shade100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(_message!),
              ),
            if (_message != null) const SizedBox(height: 16),
            FutureBuilder<Map<String, dynamic>>(
              future: _statsFuture,
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  final stats = snapshot.data!;
                  return Row(
                    children: [
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF667EEA), Color(0xFF764BA2)],
                            ),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Total Sales',
                                style: TextStyle(color: Colors.white70, fontSize: 12),
                              ),
                              Text(
                                '₹${stats['total_sales'].toStringAsFixed(2)}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFF28A745), Color(0xFF20C997)],
                            ),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Commission',
                                style: TextStyle(color: Colors.white70, fontSize: 12),
                              ),
                              Text(
                                '₹${stats['total_commission'].toStringAsFixed(2)}',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  );
                }
                return const SizedBox.shrink();
              },
            ),
            const SizedBox(height: 24),
            const Text(
              'Add New Medicine',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    TextField(
                      controller: _nameController,
                      decoration: InputDecoration(
                        labelText: 'Medicine Name',
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _companyController,
                      decoration: InputDecoration(
                        labelText: 'Company',
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _stockController,
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                              labelText: 'Stock',
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: _priceController,
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                              labelText: 'Price',
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _expiryController,
                      decoration: InputDecoration(
                        labelText: 'Expiry Date (YYYY-MM-DD)',
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _commissionController,
                            keyboardType: TextInputType.number,
                            decoration: InputDecoration(
                              labelText: 'Commission %',
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: _schemeController,
                            decoration: InputDecoration(
                              labelText: 'Scheme',
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: _addMedicine,
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                        child: const Text('Add Medicine', style: TextStyle(color: Colors.white)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Pending Orders',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            FutureBuilder<List<Order>>(
              future: _ordersFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                }
                final orders = snapshot.data ?? [];
                final pendingOrders = orders.where((o) => o.status == 'Pending').toList();
                if (pendingOrders.isEmpty) {
                  return const Text('No pending orders');
                }
                return ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: pendingOrders.length,
                  itemBuilder: (context, index) {
                    final order = pendingOrders[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Dr. ${order.doctorName}', style: const TextStyle(fontWeight: FontWeight.bold)),
                            Text('${order.qty} x ${order.medName}'),
                            Text('Bill: ₹${order.totalBill} | Commission: ₹${order.mrCommission}'),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: () => _updateOrderStatus(order.id, 'Cancelled'),
                                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                                    child: const Text('Reject', style: TextStyle(color: Colors.white)),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: () => _updateOrderStatus(order.id, 'Delivered'),
                                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                                    child: const Text('Approve', style: TextStyle(color: Colors.white)),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _companyController.dispose();
    _stockController.dispose();
    _priceController.dispose();
    _expiryController.dispose();
    _commissionController.dispose();
    _schemeController.dispose();
    super.dispose();
  }
}
