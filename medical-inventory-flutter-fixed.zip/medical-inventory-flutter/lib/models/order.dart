class Order {
  final int id;
  final String doctorName;
  final String medName;
  final int qty;
  final double totalBill;
  final double mrCommission;
  final String orderDate;
  final String status;

  Order({
    required this.id,
    required this.doctorName,
    required this.medName,
    required this.qty,
    required this.totalBill,
    required this.mrCommission,
    required this.orderDate,
    required this.status,
  });

  factory Order.fromJson(Map<String, dynamic> json) {
    return Order(
      id: json['id'],
      doctorName: json['doctor_name'],
      medName: json['med_name'],
      qty: json['qty'],
      totalBill: (json['total_bill'] as num).toDouble(),
      mrCommission: (json['mr_commission'] as num).toDouble(),
      orderDate: json['order_date'],
      status: json['status'],
    );
  }
}
