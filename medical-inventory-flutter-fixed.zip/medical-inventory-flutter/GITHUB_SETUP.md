# 🚀 GitHub Setup - Automatic APK Building

## ✅ What This Does

GitHub Actions automatically builds your APK whenever you push code. No local setup needed!

**One-time setup → Automatic APK builds forever** ✨

---

## 📋 Step-by-Step Setup

### Step 1: Create GitHub Account
- Go to [github.com/signup](https://github.com/signup)
- Create free account
- Verify email

### Step 2: Create New Repository
- Go to [github.com/new](https://github.com/new)
- **Repository name:** `medical-inventory-pro`
- **Description:** Medical Inventory Management System
- **Public** (so you can share APK link)
- Click "Create repository"

### Step 3: Push Code to GitHub

```bash
cd /home/ubuntu/medical-inventory-flutter

# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit: Medical Inventory Pro Flutter App"

# Add remote (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/medical-inventory-pro.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### Step 4: GitHub Actions Automatically Starts
- Go to your repository on GitHub
- Click "Actions" tab
- Watch the build process
- ✅ Build completes in ~5 minutes

### Step 5: Download APK

**Option A: From Actions**
1. Go to "Actions" tab
2. Click latest workflow run
3. Scroll down to "Artifacts"
4. Download `medical-inventory-apk`
5. Extract and get `app-release.apk`

**Option B: From Releases**
1. Go to "Releases" tab
2. Download APK from latest release
3. Direct download link

---

## 🎯 How to Use

### Every Time You Update Code:

```bash
# Make changes to code
git add .
git commit -m "Your commit message"
git push
```

**That's it!** GitHub Actions automatically:
- ✅ Builds APK
- ✅ Signs it
- ✅ Makes it available for download

---

## 📥 Downloading APK

### Method 1: Via GitHub Actions (Easiest)
1. Go to your repo → Actions tab
2. Click latest successful build
3. Download artifact: `medical-inventory-apk`
4. Extract ZIP file
5. Get `app-release.apk`

### Method 2: Via Releases
1. Go to your repo → Releases tab
2. Click latest release
3. Download `app-release.apk`
4. Done!

---

## 📱 Installing on Phone

### From APK File:
1. Copy APK to phone via USB
2. Open file manager
3. Tap APK file
4. Tap "Install"
5. App appears in launcher

### Via QR Code:
1. Upload APK to Google Drive
2. Get shareable link
3. Generate QR code
4. Scan on phone
5. Download and install

---

## 🔐 Demo Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | `admin123` |
| Doctor | `dr_sharma` | `doc123` |

---

## 🐛 Troubleshooting

### Build Failed?
- Check for syntax errors in Dart code
- Ensure `pubspec.yaml` is valid
- Check GitHub Actions logs for details

### Can't Find APK?
- Go to Actions tab
- Click the failed/successful workflow
- Scroll to "Artifacts" section
- Download from there

### APK Won't Install?
- Ensure Android 5.0+
- Enable "Unknown Sources" in settings
- Try different phone or emulator

---

## 🔄 Continuous Updates

Every time you push code:
1. GitHub Actions automatically triggers
2. New APK builds in ~5 minutes
3. Available for download immediately
4. Old versions kept for 30 days

---

## 📊 Workflow Status

Check build status anytime:
- Go to repository
- Click "Actions" tab
- See all builds and their status
- Download any version

---

## 🎯 Next Steps

1. Create GitHub account
2. Create repository
3. Push code (follow Step 3 above)
4. Wait 5 minutes for build
5. Download APK
6. Install on phone
7. Enjoy! 🎉

---

## 📞 Support

If build fails:
1. Check GitHub Actions logs
2. Look for error messages
3. Fix code issues
4. Push again
5. Build automatically retries

---

**Your APK will be ready in 5 minutes after pushing to GitHub!** 🚀
